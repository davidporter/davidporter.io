// cpanel - site_templates/vcard_dev/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        phone: "216 622-5203",
        fax: "",
        email: "davidbrianporter@gmail.com",
        address: "Hudson Ohio",
        social: [
            
            
            
            
            
            
        ]
    },
    style: {
        primary: "",
        accent: ""
    },
    slides: [
        {
            prefix: "",
            title: "David Porter",
            subtitle: "Expert Programmer and Creative",
            type: 'vcard',
            backgroundImage: "",
            backgroundColor: "",
            color: "",
            buttonText: "",
            buttonLink: "",
            biography: "",
            portraitImage: ""
        }
    ]
};
